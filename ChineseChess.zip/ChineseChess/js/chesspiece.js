//��������������� 
function setChesspiece(pieceName,x,y){
	var canvas=document.getElementById("chessboard");
	var target=document.getElementById(pieceName);
	target.style.left=9+canvas.offsetLeft+x*50-22+"px";
	target.style.top=9+canvas.offsetTop+y*50-23+"px";
}

//������������
function setAllChesspiece(){
	for(var i=0;i<chesspieces.length;i++){
		if(chesspieces[i][1]==-1&&chesspieces[i][2]==-1){
			continue;
		}
		else{
			setChesspiece(chesspieces[i][0],chesspieces[i][1],chesspieces[i][2]);	
		}
	}
	
	/*
	//�췽 
	setChesspiece("ju_red_1",0,9);
	setChesspiece("ju_red_2",8,9);
	setChesspiece("ma_red_1",1,9);
	setChesspiece("ma_red_2",7,9);
	setChesspiece("xiang_red_1",2,9);
	setChesspiece("xiang_red_2",6,9);
	setChesspiece("shi_red_1",3,9);
	setChesspiece("shi_red_2",5,9);
	setChesspiece("shuai_red_1",4,9);
	setChesspiece("bing_red_1",0,6);
	setChesspiece("bing_red_2",2,6);
	setChesspiece("bing_red_3",4,6);
	setChesspiece("bing_red_4",6,6);
	setChesspiece("bing_red_5",8,6);
	setChesspiece("pao_red_1",1,7);
	setChesspiece("pao_red_2",7,7);
	//�ڷ�
	setChesspiece("ju_black_1",0,0);
	setChesspiece("ju_black_2",8,0);
	setChesspiece("ma_black_1",1,0);
	setChesspiece("ma_black_2",7,0);
	setChesspiece("xiang_black_1",2,0);
	setChesspiece("xiang_black_2",6,0);
	setChesspiece("shi_black_1",3,0);
	setChesspiece("shi_black_2",5,0);
	setChesspiece("jiang_black_1",4,0);
	setChesspiece("zu_black_1",0,3);
	setChesspiece("zu_black_2",2,3);
	setChesspiece("zu_black_3",4,3);
	setChesspiece("zu_black_4",6,3);
	setChesspiece("zu_black_5",8,3);
	setChesspiece("pao_black_1",1,2);
	setChesspiece("pao_black_2",7,2); 
	*/
} 

//�������飨�������ƣ������꣬�����꣩���Ӻ��������Ϊ-1ʱ��ʾ�����Ѿ����� 
chesspieces=[
	["ju_red_1",0,9,"܇"],
	["ju_red_2",8,9,"܇"],
	["ma_red_1",1,9,"�R"],
	["ma_red_2",7,9,"�R"],
	["xiang_red_1",2,9,"��"],
	["xiang_red_2",6,9,"��"],
	["shi_red_1",3,9,"��"],
	["shi_red_2",5,9,"��"],
	["shuai_red_1",4,9,"��"],
	["bing_red_1",0,6,"��"],
	["bing_red_2",2,6,"��"],
	["bing_red_3",4,6,"��"],
	["bing_red_4",6,6,"��"],
	["bing_red_5",8,6,"��"],
	["pao_red_1",1,7,"��"],
	["pao_red_2",7,7,"��"],
	
	["ju_black_1",0,0,"��"],
	["ju_black_2",8,0,"��"],
	["ma_black_1",1,0,"��"],
	["ma_black_2",7,0,"��"],
	["xiang_black_1",2,0,"��"],
	["xiang_black_2",6,0,"��"],
	["shi_black_1",3,0,"ʿ"],
	["shi_black_2",5,0,"ʿ"],
	["jiang_black_1",4,0,"��"],
	["zu_black_1",0,3,"��"],
	["zu_black_2",2,3,"��"],
	["zu_black_3",4,3,"��"],
	["zu_black_4",6,3,"��"],
	["zu_black_5",8,3,"��"],
	["pao_black_1",1,2,"�h"],
	["pao_black_2",7,2,"�h"]
]; 

//�����������ӵ�λ��
function initChesepieces(){
	chesspieces=[
		["ju_red_1",0,9,"܇"],
		["ju_red_2",8,9,"܇"],
		["ma_red_1",1,9,"�R"],
		["ma_red_2",7,9,"�R"],
		["xiang_red_1",2,9,"��"],
		["xiang_red_2",6,9,"��"],
		["shi_red_1",3,9,"��"],
		["shi_red_2",5,9,"��"],
		["shuai_red_1",4,9,"��"],
		["bing_red_1",0,6,"��"],
		["bing_red_2",2,6,"��"],
		["bing_red_3",4,6,"��"],
		["bing_red_4",6,6,"��"],
		["bing_red_5",8,6,"��"],
		["pao_red_1",1,7,"��"],
		["pao_red_2",7,7,"��"],
		
		["ju_black_1",0,0,"��"],
		["ju_black_2",8,0,"��"],
		["ma_black_1",1,0,"��"],
		["ma_black_2",7,0,"��"],
		["xiang_black_1",2,0,"��"],
		["xiang_black_2",6,0,"��"],
		["shi_black_1",3,0,"ʿ"],
		["shi_black_2",5,0,"ʿ"],
		["jiang_black_1",4,0,"��"],
		["zu_black_1",0,3,"��"],
		["zu_black_2",2,3,"��"],
		["zu_black_3",4,3,"��"],
		["zu_black_4",6,3,"��"],
		["zu_black_5",8,3,"��"],
		["pao_black_1",1,2,"�h"],
		["pao_black_2",7,2,"�h"]
	]; 
}

$(document).ready(function(){
	setAllChesspiece();
	//console.log(chesspieces);
});

//���ڴ�С�仯ʱ 
window.onresize=function(){
	chessboard.fontDrawing();
	setAllChesspiece();
	setChessmanual();
};

//�����ƶ�(index:���ӱ��,x:Ŀ�ĵغ�����,y:Ŀ�ĵ�������)
function movePiece(index,x,y){
	var piece=document.getElementById(chesspieces[index][0]);
	var left=(x-chesspieces[index][1])*50;
	var top=(y-chesspieces[index][2])*50;
	var distance_left="+=0px";
	var distance_top="+=0px";
	if(left>0){
		distance_left="+="+left+"px";
		//console.log(distance_left);
		//$(piece).animate({left:distance_left});
	}else if(left<0){
		left=0-left;
		distance_left="-="+left+"px";
		//console.log(distance_left);
		//$(piece).animate({left:distance_left});
	}
	if(top>0){
		distance_top="+="+top+"px";
		//console.log(distance_top);
		//$(piece).animate({top:distance_top});
	}else if(top<0){
		top=0-top;
		distance_top="-="+top+"px";
		//console.log(distance_top);
		//$(piece).animate({top:distance_top});
	}
	$(piece).animate({left:distance_left,top:distance_top});
	chesspieces[index][1]=x;
	chesspieces[index][2]=y;
} 
